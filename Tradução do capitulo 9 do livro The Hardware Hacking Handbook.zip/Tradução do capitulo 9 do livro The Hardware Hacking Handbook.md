﻿**Capítulo 9 do livro** **The Hardware Hacking Handbook**      

`             `Hora da bancada:
`           `Análise simples de energia


Neste capítulo, vamos apresentar um ambiente de laboratório simples que permite que você experimente alguns exemplos de código. Em vez de atacar dispositivos sobre os quais não sabemos nada, começaremos a atacar dispositivos reais que temos em mãos em nosso laboratório com algoritmos específicos de nossa escolha. 
Essa prática nos permitirá ganhar experiência nesses tipos de ataques, ao invés de termos que fazer muitas suposições sobre o que um dispositivo "fechado" está fazendo. Primeiro, vamos passar pelos princípios básicos da construção da configuração de análise de energia simples (SPA), e depois vamos programar um Arduino com uma verificação de senha vulnerável à SPA para ver se podemos extrair a senha. Por fim, realizaremos o mesmo experimento com o ***ChipWhisperer-Nano***. Considere este capítulo como se estivesse estalando os dedos para se aquecer antes de realmente tocar piano.








**O Laboratório Doméstico**

Para construir um laboratório de SPA simples, você precisa de uma ferramenta para medir traços de energia, um dispositivo-alvo em uma placa de circuito habilitada para medição de energia, e um computador que instrua o alvo a realizar uma operação enquanto grava os traços de energia e entrada/saída do dispositivo.

**Montando uma Configuração Básica de Hardware**


**Seu laboratório não precisa ser caro ou complicado, como mostra a Figura 9-1.**

![Uma imagem contendo no interior, eletrônico, mesa, circuito

Descrição gerada automaticamente](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.001.png)

**Figura 9-1: Uma plataforma experimental caseira** 
**
`     `Este simples laboratório caseiro consiste em um osciloscópio conectado via **USB 1**, um dispositivo-alvo em uma protoboard com eletrônicos que possibilitam medições 2 e um computador padrão com um adaptador **USB-seria**l 3. O microcontrolador **ATmega328P**, utilizado em um Arduino, está montado em uma placa especial com um resistor de medição de corrente.

**Osciloscópios Básicos**

Ao usar um osciloscópio regular, o requisito mais importante é que ele seja capaz de amostrar a 100 MS/s (mega amostras por segundo) ou mais em dois canais. Muitos osciloscópios especificam uma taxa máxima de amostragem que você só pode obter em um único canal. Se você usar dois canais, a taxa de amostragem em cada canal é a metade da máxima, o que significa que um osciloscópio de 100 MS/s só pode amostrar a 50 MS/s se você quiser medir duas entradas ao mesmo tempo. Para esses experimentos, usaremos o segundo canal apenas como um disparador. Seu osciloscópio pode ter um disparador externo (que ainda permite obter a taxa máxima de amostragem de um canal), mas caso contrário, certifique-se de que pode amostrar em dois canais simultaneamente a 100 MS/s ou melhor. Atacar implementações mais avançadas, como AES em hardware, exigirá taxas de amostragem muito mais rápidas às vezes 1 GS/s ou mais.

Osciloscópios genéricos de baixo custo podem não ter uma interface de computador útil. Por exemplo, você encontrará osciloscópios conectados via USB que não possuem uma API para permitir a interface com o dispositivo. Ao comprar um osciloscópio para análise de canal lateral, certifique-se de que pode controlar o dispositivo a partir do seu computador e que pode baixar rapidamente os dados do osciloscópio.

Além disso, preste atenção ao tamanho do buffer de amostra. Dispositivos de baixo custo têm um buffer pequeno, por exemplo, apenas 15.000 amostras, o que dificultará muito o seu trabalho. Isso ocorre porque você precisará acionar a captura no momento exato da operação sensível; caso contrário, você excederá o buffer de memória do osciloscópio. Você também não poderá realizar certos trabalhos, como análise de energia simples em algoritmos de chave pública mais longos que exigiriam um buffer muito maior.

Dispositivos de amostragem especiais que permitem amostragem síncrona podem reduzir os requisitos de taxa de amostragem mantendo uma relação entre o relógio do dispositivo e seu relógio de amostragem (como faz o ***ChipWhisperer**)*. Consulte o Apêndice A para obter mais informações sobre osciloscópios.

**Escolhendo um Microcontrolador**

Escolha um microcontrolador que você possa programar diretamente e que não esteja executando nenhum sistema operacional. O Arduino é uma escolha perfeita. Não inicie sua carreira em análise de canal lateral tentando usar um alvo como um ***Raspberry Pi*** ou ***BeagleBone***. Esses produtos têm muitos fatores complicadores, como a dificuldade de obter um disparo confiável, altas velocidades de ***clock*** e seus sistemas operacionais. Estamos desenvolvendo uma habilidade, então vamos começar no modo fácil.

**Construindo uma Placa Alvo (Target Board)** 

A primeira coisa que precisamos construir é uma placa alvo com microcontrolador que tenha um resistor shunt inserido na linha de alimentação. Resistor shunt é um termo genérico que damos a um resistor que inserimos no caminho de um circuito para medir corrente. O fluxo de corrente através desse resistor causará o desenvolvimento de uma tensão através dele, e podemos medir essa tensão usando um osciloscópio. A Figura 9-1 mostra um exemplo de um alvo de teste. A Figura 9-2 detalha a inserção de um resistor shunt, onde o lado inferior do resistor shunt vai para o canal do osciloscópio. A lei de Ohm nos diz que uma tensão "desenvolvida" através de um resistor é igual à resistência multiplicada pela corrente **(V = I × R**). A polaridade da tensão será tal que uma tensão mais baixa estará presente no lado inferior. Se o lado superior estiver em 3,3 V e o lado inferior em 2,8 V, isso significa que 0,5 V (3,3 - 2,8) foi desenvolvido através do resistor.

![Diagrama

Descrição gerada automaticamente](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.002.png)

Figura 9-2: Um resistor shunt facilita a medição do consumo de energia.

Se quiséssemos medir apenas a tensão através do resistor shunt, poderíamos usar um instrumento chamado sonda diferencial. Com uma sonda diferencial, obteremos apenas a tensão exata através do próprio resistor shunt, o que deve fornecer a medição mais precisa.

Um método mais simples que não requer equipamentos adicionais (e como trabalharemos neste laboratório) é assumir que o lado superior do resistor shunt está conectado a uma fonte de alimentação limpa e constante, o que significa que qualquer ruído no lado superior do resistor shunt adicionará ruído à medição no lado inferior. Mediremos o consumo de energia através deste resistor shunt simplesmente medindo a tensão no lado inferior, que será o valor de nossa constante "lado superior" de tensão menos a queda no resistor shunt. Conforme a corrente aumenta no shunt, a queda de tensão no shunt também aumenta, e assim a tensão do "lado inferior" se torna menor.

O valor da resistência que você precisará para o seu resistor shunt depende do consumo de energia atual do seu dispositivo-alvo. Usando a lei de Ohm, V = I × R, você pode calcular valores razoáveis de resistência. A maioria dos osciloscópios possui boa resolução de tensão de 50 mV a 5 V. A corrente (I) é determinada pelo dispositivo, mas variará de dezenas de mA para microcontroladores a vários A para grandes System-on-Chips (SoCs). Por exemplo, se o seu alvo for um microcontrolador pequeno com 50 mA, você deve ser capaz de usar uma resistência de 10 Ω a 50 Ω, mas uma matriz de portas programável em campo com consumo de 5 A pode exigir 0,05 Ω a 0,5 Ω. Resistores de valor mais alto produzem uma queda de tensão maior que fornece um sinal forte para o seu osciloscópio, mas isso pode reduzir a tensão do dispositivo a um ponto tão baixo que ele pare de funcionar.




A Figura 9-3 mostra um esquema da placa alvo 2 da Figura 9-1.

![Diagrama, Esquemático

Descrição gerada automaticamente](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.003.png)
Figura 9-3: Um esquema da placa alvo

`      `O microcontrolador ***ATmega328P*** executa o código-alvo, um resistor (R2) nos permite fazer medições de energia, e a filtragem de ruído da fonte de alimentação de entrada é feita com C1, C2, C3 e R1. Um adaptador serial ***USB-TTL*** externo está conectado às linhas RX e TX. Note que a fonte de alimentação digital não possui capacitores de desacoplamento; eles filtrariam detalhes do consumo de energia que contêm informações potencialmente interessantes. Você pode modificar facilmente este circuito para usar outros microcontroladores, se preferir. Você precisará ser capaz de programar o microcontrolador com o seu código-alvo, o que pode significar mover o chip físico entre a protoboard do alvo e o Arduino. Um Arduino Uno usa o mesmo microcontrolador ***ATmega328P*** que mencionamos antes, então sempre que dizemos "Arduino", queremos dizer uma placa que pode ser usada para programar o microcontrolador.

**Comprando um Conjunto** 

Se você preferir não construir seu próprio laboratório para análise de canal lateral, você pode comprá-lo. O ***ChipWhisperer-Nano*** (mostrado na Figura 9-4) ou o ***ChipWhisperer-Lite*** (mostrado na Figura 9-5) substituem todo o hardware mostrado na Figura 9-1 por cerca de US$50 ou US$250, respectivamente.


![Tela de um aparelho eletrônico

Descrição gerada automaticamente com confiança média](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.004.png)

Figura 9-4: O ChipWhisperer-Nano


O ***ChipWhisperer-Nano*** é um dispositivo que permite programar o STM32F0 incluído com vários algoritmos e realizar análise de energia. Você pode separar o alvo incluído para examinar outros dispositivos. A funcionalidade de ***glitching*** é muito limitada em comparação com ***o ChipWhisperer-Lite.***

![Circuito eletrônico com botões

Descrição gerada automaticamente](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.005.png)

Figura 9-5: O ChipWhisperer-Lite

O ***ChipWhisperer-Lite*** fornece hardware de captura junto com uma placa-alvo de exemplo. O alvo incluído está disponível como um Atmel XMEGA ou STM32F303 ARM. Além da análise de canal lateral, este dispositivo também permite realizar experimentos de ***glitch*** de ***clock*** e voltagem. Novamente, você pode separar o alvo incluído para examinar dispositivos mais avançados. Esses dispositivos incluem tanto o alvo quanto o hardware de captura em uma única placa. O ***ChipWhisperer-Lite*** é um design de código aberto, então você também pode construí-lo você mesmo. Alternativamente, ferramentas comerciais como o ***Inspector da Riscure*** ou a Estação de Trabalho DPA da CRI estão disponíveis; elas são desenvolvidas para alvos de maior complexidade e segurança, mas estão fora do orçamento do hacker de hardware médio.

**Preparando o Código-Alvo**

Vamos assumir um Arduino como o alvo por enquanto e depois demonstraremos o mesmo ataque em um ***ChipWhisperer-Nano***. Independentemente da sua escolha de hardware, você precisará programar o microcontrolador para executar o algoritmo de criptografia ou verificação de senha. O Exemplo 9-1 mostra um exemplo do código de firmware que você precisa programar em seu alvo.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

// Trigger is Pin 2

int triggerPin = 2;

String known\_passwordstr = String("ilovecheese");

String input\_passwordstr;

char input\_password[20];

char tempchr;

int index;

// the setup routine runs once when you press reset:

void setup() {

` `// initialize serial communication at 9600 bits per second:

` `Serial.begin(9600);

` `pinMode(triggerPin, OUTPUT);

` `tempchr = '0';

` `index = 0;

}

// the loop routine runs over and over again forever:

void loop() {

` `//Wait a little bit after startup & clear everything

` `digitalWrite(triggerPin, LOW);

` `delay(250);

` `Serial.flush();

` `Serial.write("Enter Password:");

` `// wait for last character

` `while ((tempchr != '\n') && (index < 19)){

` `if(Serial.available() > 0){

` `tempchr = Serial.read();

` `input\_password[index++] = tempchr;

` `}

` `}

` `// Null terminate and strip non-characters

` `input\_password[index] = '\0';

` `input\_passwordstr = String(input\_password);

` `input\_passwordstr.trim();

` `index = 0;

` `tempchr = 0;

1 digitalWrite(triggerPin, HIGH);

2 if(input\_passwordstr == known\_passwordstr){

` `Serial.write("Password OK\n");

` `} else {

` `//Delay up to 500ms randomly

` `3 delay(random(500));

` `Serial.write("Password Bad\n");

` `}

} 
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Lista 9-1: Firmware de microcontrolador de amostra usando Arduino para realizar uma operação simples com um disparador.


O alvo primeiro lê uma senha do usuário. Em seguida, o alvo compara essa senha com a senha armazenada 2 (neste caso, a senha **hardcoded** é **ilovecheese**). Uma linha de E/S específica é colocada em nível alto durante a operação de comparação de senha, permitindo que você acione seu osciloscópio para medir o sinal durante esta operação 1. Este firmware tem um truque na manga. Mesmo que ele use uma comparação de ***string*** vazia 2 (como em nossa introdução sobre ataques de ***timing*** no Exemplo 8-1), ele dificulta os ataques de timing ao fazer uma espera aleatória de até 500ms no final da operação 3, tornando-o propenso a um ataque de SPA. 





**Montando o Conjunto**

No lado do computador, seu trabalho envolverá o seguinte:

\- Comunicar-se com o dispositivo-alvo (enviar comandos e dados e receber uma resposta)

\- Configurar o osciloscópio conforme necessário (canais, disparadores e escalas)

\- Baixar dados do osciloscópio para o computador

\-  Armazenar o traço de energia e os dados enviados ao dispositivo em um banco de dados ou arquivo

Vamos analisar os requisitos para cada um desses passos nas próximas seções. O objetivo final é medir o consumo de energia de um microcontrolador enquanto executa um programa simples, como mostrado no Exemplo 9-1.

**Comunicando-se com o Dispositivo-Alvo**

Como você está direcionando um dispositivo que você mesmo programa, você pode definir seu próprio protocolo de comunicação. No Exemplo 9-1, é simplesmente uma interface serial que lê uma senha. Para simplicidade, a senha "correta" é codificada diretamente no programa, mas em geral, é bom permitir a configuração das "informações sensíveis" (como a senha). Essa prática permite que você experimente mais facilmente (por exemplo, com senhas mais longas e mais curtas). Quando você começa a visar criptografia, essa prática também se aplica: a configuração do material-chave a partir do computador possibilita experimentações.

A outra parte da comunicação é acionar o osciloscópio. Enquanto o dispositivo-alvo está executando a tarefa com a "operação sensível", você precisa monitorar o consumo de energia do dispositivo. O Exemplo 9-1 mostra o acionamento, onde colocamos uma linha de disparo em nível alto logo antes da comparação ocorrer e a baixamos novamente após a comparação.

**O Resistor Shunt**

O sinal de saída do resistor shunt é bastante forte e deve ser capaz de alimentar diretamente o seu osciloscópio. Conecte o sinal diretamente ao seu osciloscópio usando a entrada do conector BNC, em vez de passá-lo pelas sondas, o que pode introduzir ruído por meio da conexão de terra. Além disso, se o seu osciloscópio tiver apenas sondas fixos de 10:1, você reduzirá a voltagem de pico a pico. Depois de fazer isso, o seu osciloscópio pode medir as diferenças de voltagem causadas pela variação no consumo de energia do alvo.

**Configurações do Osciloscópio** 

Você precisará ajustar algumas configurações no seu osciloscópio de forma adequada: a faixa de voltagem, acoplamento e taxa de amostragem. Isso é "Osciloscópio 101", então daremos apenas algumas dicas breves sobre aspectos específicos ao realizar capturas de canal lateral. Mais detalhes sobre o uso de osciloscópios podem ser encontrados na seção "Osciloscópio Digital" no Capítulo 2. Se precisar comprar um osciloscópio, consulte a seção "Visualizando Formas de Onda Analógicas (Osciloscópios)" no Apêndice A.

A faixa de voltagem deve ser selecionada alta o suficiente para que o sinal capturado não seja cortado (clipping). Por exemplo, quando você tem um sinal de 1,3 V, mas sua faixa está configurada para 1,0 V, você perderá todas as informações acima de 1,0 V. Por outro lado, ela precisa ser selecionada baixa o suficiente para não causar erros de quantização. Isso significa que se sua faixa estiver configurada para 5 V, mas você tem um sinal de 1,3 V, você desperdiçou 3,7 V de faixa. Se o seu osciloscópio oferecer uma escolha entre 1 V e 2 V, para o sinal de 1,3 V, você escolheria 2 V.

O modo de acoplamento de entrada do seu osciloscópio geralmente não é muito crítico. A menos que você tenha uma boa razão para não o fazer, use o modo acoplado a AC, pois ele centraliza o sinal em torno do nível de 0 V. Você também pode usar o modo acoplado a DC e ajustar o offset para alcançar os mesmos resultados. A vantagem do modo acoplado a AC é que ele elimina qualquer mudança gradual na voltagem ou ruído de frequência muito baixa que possa complicar as medições se, por exemplo, a saída do seu regulador de voltagem se alterar conforme o sistema aquece. Ele também compensará o desvio de DC introduzido se você estiver usando um shunt no lado do VCC, como mostramos na Figura 9-2. Desvios de DC geralmente não carregam informações de canal lateral.

Quanto à taxa de amostragem, o trade-off é o aumento do tempo de processamento, mas melhor qualidade de captura em uma taxa mais alta versus processamento mais rápido, mas com menor qualidade em uma taxa mais baixa. Ao começar, use a regra prática de que você deve amostrar de uma a cinco vezes a velocidade de ***clock*** do seu alvo.

Seu osciloscópio pode ter outras características úteis também, como um limite de largura de banda de 20 MHz que pode reduzir ruídos de alta frequência. Você também pode introduzir filtros passa-baixa analógicos com o mesmo efeito. Se estiver atacando dispositivos de baixa frequência, essa redução de ruído de alta frequência seria útil, mas se estiver atacando um dispositivo muito rápido, você pode precisar de dados dos componentes de alta frequência. Uma boa prática é colocar um limitador de largura de banda cerca de cinco vezes a sua taxa de amostragem. Por exemplo, um alvo de 5 MHz pode ser amostrado a 10 MS/s e limitado a uma largura de banda de 50 MHz.

Certifique-se de experimentar para determinar a melhor configuração de medição para qualquer dispositivo e algoritmo específico. É uma boa experiência de aprendizado e ajudará você a entender como as configurações afetam a qualidade e a velocidade de aquisição.



**Comunicando-se com o Osciloscópio**

Para realmente realizar o ataque, você precisará de alguma forma de baixar os dados do traço para o computador. Para ataques simples de análise de energia, você pode ser capaz de fazê-lo inspecionando visualmente o display do osciloscópio. No entanto, qualquer um dos ataques mais avançados exigirá que você baixe os dados do osciloscópio para o computador.

O método de comunicação com seu osciloscópio dependerá quase inteiramente do fornecedor do osciloscópio. Alguns fornecedores têm suas próprias bibliotecas com ligações de linguagem para usar essa biblioteca em linguagens como C e Python. Muitos outros fornecedores dependem do ***Virtual Instrument Software Architecture*** (VISA), um padrão da indústria para comunicações entre equipamentos de teste. Se o seu osciloscópio suporta VISA, você deve ser capaz de encontrar bibliotecas de alto nível em quase todas as linguagens para ajudá-lo a interagir com ele, como o ***PyVISA*** para Python. Você precisará implementar comandos ou opções específicos para o seu osciloscópio, mas o fornecedor deve fornecer algumas instruções.

**Armazenamento de Dados**

Como você armazena seus traços depende quase inteiramente da plataforma de análise planejada. Se você planeja fazer a análise inteiramente em Python, pode procurar o formato de armazenamento que funcione com a popular biblioteca ***NumPy***. Se estiver usando o MATLAB, você aproveitará o formato de arquivo nativo do MATLAB. Se planeja experimentar com computação distribuída, precisará investigar o sistema de arquivos preferido para o seu cluster.

Ao trabalhar com conjuntos de traços realmente grandes, o formato de armazenamento será importante e você vai querer otimizá-lo para um acesso linear rápido. Em laboratórios profissionais, conjuntos de 1 TB não são exceção. Por outro lado, para o seu trabalho e investigação iniciais, os requisitos de armazenamento de dados devem ser bastante pequenos. Atacar uma implementação de software em um microcontrolador de 8 bits pode exigir apenas 10 ou 20 medições de energia, então quase qualquer coisa melhor do que copiar/colar os dados de uma planilha funcionará!

**Reunindo Tudo: Um Ataque de SPA**

Com nossa nova configuração, vamos realizar o ataque de SPA real, trabalhando com o código do Exemplo 9-1. Como mencionado anteriormente, este código possui uma comparação de senha que vaza informações. A espera aleatória no final do código oculta a vazamento de tempo, então não é diretamente explorável através do tempo. Teremos que olhar mais de perto, usando SPA em traços, para ver se podemos identificar as comparações individuais de caracteres. Se os traços revelarem qual caractere está incorreto, podemos realizar um ataque de força bruta muito limitado para recuperar a senha, exatamente como fizemos nos ataques de tempo puro no Capítulo 8.

Primeiro, precisaremos fazer um pouco de preparação adicional em nosso Arduino. Em seguida, mediremos os traços de energia quando fornecermos senhas corretas, parcialmente corretas e incorretas. Se esses traços revelarem o índice do primeiro caractere errado, podemos realizar um ataque de força bruta para recuperar a senha correta.




**Preparando o Alvo** 

Para demonstrar uma abordagem sem solda para capturar traços, precisamos ampliar a configuração mostrada na Figura 9-1. Basicamente, pegamos um Arduino Uno e simplesmente movemos o microcontrolador ATmega328P para um protoboard (veja a Figura 9-6). Como mencionado anteriormente, precisamos do shunt de corrente no pino VCC, por isso não podemos usar apenas uma placa de Arduino comum (pelo menos sem fazer algumas soldagens).

![Uma imagem contendo circuito, mesa

Descrição gerada automaticamente](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.006.png)



Figura 9-6: O humilde Arduino usado como alvo de ataques de análise de canal lateral

![Diagrama

Descrição gerada automaticamente](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.007.png)
Figura 9-7: Detalhes do cabeamento necessário para o Arduino Uno (esta imagem foi criada com o Fritzing).

Os pinos 9 e 10 são conectados do soquete vazio do circuito integrado (CI), onde o microcontrolador costumava estar, para o protoboard. Esses fios de ligação trazem a frequência do cristal da placa conforme necessário pelo CI do microcontrolador. Os fios devem ser o mais curtos possível. Não é uma boa ideia passar essas linhas sensíveis para fora da placa como fizemos, mas na prática, tende a funcionar. Se você tiver dificuldade em fazer o sistema funcionar, pode ser que essas linhas estejam muito longas.

O valor dos resistores e capacitores não é crítico. Os resistores aqui são de 100 Ω, mas qualquer coisa de 22 a 100 Ω deve funcionar. Capacitores na faixa de 100μF a 330μF funcionarão. (O esquemático na Figura 9-3 mostra alguns detalhes. Observe que Y1, C5 e C6 mostrados na Figura 9-3 não são necessários aqui, pois essas partes estão na placa base do Arduino.)

Agora que o Arduino foi modificado para medidas de potência, programamos o código do Exemplo 9-1. Após conectar com um terminal serial, você deve ter um prompt onde pode inserir sua senha (veja a Figura 9-8).

Certifique-se de testar se o código se comporta corretamente tanto para uma senha válida quanto para uma senha inválida. Você pode fazer isso digitando manualmente uma senha ou criando um programa de teste que se comunique diretamente com o código alvo. Neste ponto, você está pronto para um ataque!

![Interface gráfica do usuário, Texto, Email

Descrição gerada automaticamente](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.008.png)

Figura 9-8: Saída serial do Arduino programado





**Preparando o Osciloscópio** 

Configure seu osciloscópio para disparar na linha de E/S digital em uso. Usamos "Digital IO 2", que é o pino 4 no chip ATmega328P. O código no alvo eleva a linha para alto logo antes da operação sensível (neste caso, a comparação de senha).

Primeiro, experimente enviando repetidamente a mesma senha. Você deve obter traços muito semelhantes. Caso contrário, verifique sua configuração. Seu gatilho pode não estar sendo capturado pelo osciloscópio, ou talvez seu programa de teste não esteja sendo executado corretamente. Os traços capturados à esquerda da linha pontilhada na próxima Figura 9-9 fornecem uma ideia de quão semelhantes os traços devem parecer.

Depois de se certificar de que a configuração de medição está funcionando, experimente com várias configurações do osciloscópio, seguindo nossos conselhos da seção anterior. Um Arduino Uno opera a 16 MHz, então ajuste seu osciloscópio para algo entre 20 MS/s e 100 MS/s. Ajuste a faixa do seu osciloscópio para se ajustar ao sinal sem cortar.

Para facilitar a montagem, usamos sondas de osciloscópio. Como mencionado anteriormente, isso causará alguma perda de sinal em comparação com a alimentação de um fio conectado por BNC diretamente ao osciloscópio. Neste alvo, há muito sinal, então não é um grande problema.

Se suas sondas de osciloscópio forem comutáveis entre 10× e 1×, você pode achar que elas funcionam muito melhor na posição 1×. A posição 1× oferece menos ruído, mas com largura de banda muito reduzida. Para este caso específico, a menor largura de banda é realmente útil, então preferimos usar a configuração 1×. Se seu osciloscópio tiver um limite de largura de banda (muitos têm a opção de limite de largura de banda de 20 MHz), ative-o para ver se o sinal fica mais claro. Se estiver pensando em adquirir um osciloscópio para isso, abordaremos que tipo de opções você pode precisar na Seção A do Apêndice.









**Análise do Sinal** 

Agora você pode começar a experimentar com diferentes senhas; você deve ver uma diferença perceptível ao enviar as senhas corretas e incorretas. A Figura 9-9 mostra um exemplo da medição de energia registrada com diferentes senhas ao executar: os traços de energia para a senha correta (topo, ilovecheese), uma senha totalmente incorreta (parte inferior, test) e uma senha parcialmente correta (meio, iloveaaaaaa).

![Gráfico

Descrição gerada automaticamente](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.009.png)

Figura 9-9: Os traços de energia são mostrados para senhas corretas, parcialmente corretas e incorretas; as setas indicam a operação de comparação de caracteres. O sinal preto sobreposto a cada traço é o sinal de gatilho.

Uma clara diferença é visível entre os dois traços superiores e o traço inferior. A função de comparação de ***strings*** detecta rapidamente se o número de caracteres difere — o traço inferior mostra um sinal de gatilho mais curto. A área mais interessante é onde o mesmo número de caracteres é comparado, mas com valores incorretos, como mostrado nos traços superior e médio. Para esses traços, a assinatura de energia é a mesma até a linha pontilhada, após a qual agora, ao observar o traço da senha (iloveaaaaaa) no meio, você pode ver apenas cinco desses segmentos. Cada "segmento" representa uma única iteração por algum laço de comparação, então o número desses segmentos corresponde ao comprimento do prefixo da senha correta. Assim como no ataque de tempo no Capítulo 8, isso significa que só precisamos adivinhar cada caractere de entrada possível, um de cada vez, e isso significa que podemos adivinhar a senha muito rapidamente (supondo que escrevamos um script para fazer isso).



**Automatizando a Comunicação e Análise**

Você vai querer ter uma interface tanto paro o osciloscópio quanto para o alvo a algum ambiente de programação para esta seção. Essa interface permitirá que você escreva um script para enviar senhas arbitrariamente enquanto nota a medição de energia. Vamos usar esse script para determinar quantos caracteres iniciais foram aceitos.

Os detalhes desse script vão depender muito do sistema que você está usando para baixar dados de um osciloscópio. O ***Listing*** 9-2 mostra um script que funciona com um dispositivo ***USB PicoScope*** e o código de verificação de senha do Arduino. Você precisará ajustar as configurações para o seu alvo específico; não é apenas uma tarefa de copiar-colar-executar. 

#Simple Arduino password SPA/timing characterization

import numpy as np

import pylab as plt

import serial

import time

#picoscope module from https://github.com/colinoflynn/pico-python

from picoscope import ps2000

#Adjust serial port as needed

try:

` `ser = serial.Serial(

` `port='com42',

` `baudrate=9600,

` `timeout=0.500

` `)

` `ps = ps2000.PS2000()

` `print("Found the following picoscope:")

` `print(ps.getAllUnitInfo())

` `#Need at least 13us from trigger

` `obs\_duration = 13E-6

` `#Sample at least 4096 points within that window

` `sampling\_interval = obs\_duration / 4096

` `#Configure timebase

(actualSamplingInterval, nSamples, maxSamples) = \

` `ps.setSamplingInterval(sampling\_interval, obs\_duration)

` `print("Sampling interval = %f us" % (actualSamplingInterval \*

` `nSamples \* 1E6))

` `#Channel A is trigger

` `ps.setChannel('A', 'DC', 10.0, 0.0, enabled=True)

` `ps.setSimpleTrigger('A', 1.0, 'Rising', timeout\_ms=2000, enabled=True)

` `#50mV range on channel B, AC coupled, 20MHz BW limit

` `ps.setChannel('B', 'AC', 0.05, 0.0, enabled=True, BWLimited=True)

` `#Passwords to check

` `test\_list = ["ilovecheese", "iloveaaaaaa"]

` `data\_list = []

` `#Clear system

` `ser.write((test\_list[0] + "\n").encode("utf-8"))

` `ser.read(128)

` `for pw\_test in test\_list:

` `#Run capture

` `ps.runBlock()

` `time.sleep(0.05)

` `ser.write((pw\_test + "\n").encode("utf-8"))

` `ps.waitReady()

` `print('Sent "%s" - received "%s"' %(pw\_test, ser.read(128)))

` `data = ps.getDataV('B', nSamples, returnOverflow=False)

` `#Normalize data by std-dev and mean

` `data = (data - np.mean(data)) / np.std(data)

` `data\_list.append(data)

` `#Plot password tests

` `x = range(0, nSamples)

` `pltstyles = ['-', '--', '-.']

` `pltcolor = ['0.5', '0.1', 'r']

` `plt.figure().gca().set\_xticks(range(0, nSamples, 25))

` `for i in range(0, len(data\_list)):

` `plt.plot(x, data\_list[i], pltstyles[i], c=pltcolor[i], label= \

` `test\_list[i])

` `plt.legend()

` `plt.xlabel("Sample Number")

` `plt.ylabel("Normalized Measurement")

` `plt.title("Password Test Plot")

` `plt.grid()

` `plt.show()

finally:

` `#Always close off things

` `ser.close()

` `ps.stop()

` `ps.close()

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Lista 9-2: Um script de exemplo para conectar um computador a um PicoScope da série 2000 juntamente com seu alvo Arduino.

O script em Python na Lista 9-2 irá exibir um diagrama como o mostrado na Figura 9-10. Note que os marcadores neste diagrama foram adicionados com código adicional não mostrado na Lista 9-2. Se você quiser ver o código exato de geração dos marcadores, consulte o repositório complementar, que inclui o código usado para gerar a Figura 9-10. 

![Gráfico

Descrição gerada automaticamente](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.010.png)Figura 9-10: Dois traços de energia de duas tentativas de senha diferentes (correta marcada com círculos; incorreta marcada com quadrados)

A Figura 9-10 está ampliada em comparação com a Figura 9-9, com a comparação começando na amostra 148. A linha contínua é para a senha correta; a senha parcialmente correta é mostrada com traços. É possível observar que a cada 25 amostras, a partir da amostra número 148, um padrão se repete - aparentemente um padrão por comparação. As linhas se sobrepõem por cinco das comparações. Observe que na amostra número 273, a senha correta e a senha parcialmente correta divergem, o que coincide com a ideia de que os primeiros cinco caracteres (***ilove***) são os mesmos entre ambas as tentativas de senha. Para enfatizar isso, marcamos o valor do traço de energia da senha correta com círculos a cada 25 amostras, e o valor do traço de energia da senha incorreta com quadrados a cada 25 amostras. Observe que o quadrado e o círculo estão próximos um do outro nas cinco primeiras localizações marcadas, mas na sexta localização, eles são notavelmente diferentes.

Para automatizar esse ataque, podemos comparar o valor da amostra do traço de energia a cada 25 amostras, começando na amostra 148. Usando os marcadores da Figura 9-10, podemos ver que há uma voltagem de limiar em torno de 1,2 V que poderia ser usada para separar as iterações boas e ruins.

Como sabíamos que a comparação começava no ponto de amostra 148? Você pode determinar o início da comparação usando a senha "totalmente incorreta", que deve mostrar divergência assim que a comparação começar. Para fazer isso, você terá que adicionar à lista de senhas testadas uma terceira opção que envie uma senha totalmente incorreta, como **aaaaaaaaaaa.**


**Fazendo Script o Ataque**

Nós usamos a técnica de "análise rápida dos traços" para identificar os segmentos, que é o ponto de partida usual para a SPA, mas para fazer o script disso, precisamos ser um pouco mais precisos. Precisamos de um indicador que diga a um script se há um segmento. Com isso em mente, elaboramos a seguinte regra: um índice de segmento de comparação de caracteres i é detectado como bem-sucedido se houver um pico maior que 1,2 V na amostra 148 + 25i. Você notará na Figura 9-10 que a senha incorreta divergiu na amostra 273, e nesse momento a trilha da senha incorreta teve um valor de cerca de 1,06 V. Observe que os traços podem ter ruído e talvez seja necessário adicionar filtragem ao sinal ou verificar algumas vezes para confirmar se seus resultados correspondem. Também é necessário usar uma busca em uma área ao redor da amostra por ± 1 amostras porque o osciloscópio pode ter algum ***jitter***. Uma rápida verificação na Figura 9-10 mostra que isso deve funcionar. Com esse conhecimento, podemos criar o script em Python no Lista 9-3, que adivinha automaticamente a senha correta.
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#Simple Arduino password SPA/timing attack

import numpy as np

import pylab as plt

import serial

import time

#picoscope module from https://github.com/colinoflynn/pico-python

from picoscope import ps2000

#Adjust serial port as needed

try:

` `ser = serial.Serial(

` `port='com42',

` `baudrate=9600,

` `timeout=0.500

` `)

` `ps = ps2000.PS2000()

` `print("Found the following picoscope:")

` `print(ps.getAllUnitInfo())

` `#Need at least 13us from trigger

` `obs\_duration = 13E-6

` `#Sample at least 4096 points within that window

` `sampling\_interval = obs\_duration / 4096

` `#Configure timebase

` `(actualSamplingInterval, nSamples, maxSamples) = \

` `ps.setSamplingInterval(sampling\_interval, obs\_duration)

#Channel A is trigger

` `ps.setChannel('A', 'DC', 10.0, 0.0, enabled=True)

` `ps.setSimpleTrigger('A', 1.0, 'Rising', timeout\_ms=2000, enabled=True)

` `#50mV range on channel B, AC coupled, 20MHz BW limit

` `ps.setChannel('B', 'AC', 0.05, 0.0, enabled=True, BWLimited=True)

` `guesspattern="abcdefghijklmnopqrstuvwxyz"

` `current\_pw = ""

` `start\_index = 148

` `inc\_index = 25

` `#Currently uses fixed length of 11, could also use response

` `for guesschar in range(0,11):

` `for g in guesspattern:

` `#Make guess, ensure minimum length too

` `pw\_test = current\_pw + g

` `pw\_test = pw\_test.ljust(11, 'a')

` `#Run capture

` `ps.runBlock()

` `time.sleep(0.05)

` `ser.write((pw\_test + "\n").encode("utf-8"))

` `ps.waitReady()

` `response = ser.read(128).decode("utf-8").replace("\n","")

` `print('Sent "%s" - received "%s"' %(pw\_test, response))

` `if "Password OK" in response:

` `print("\*\*\*\*FOUND PASSWORD = %s"%pw\_test)

` `raise Exception("password found")

` `data = ps.getDataV('B', nSamples, returnOverflow=False)

` `#Normalized by std-dev and mean

` `data = (data - np.mean(data)) / np.std(data)

` `#Location of check

` `idx = (guesschar\*inc\_index) + start\_index

` `#Empirical threshold, check around location a bit

` `if max(data[idx-1 : idx+2]) > 1.2:

` `print("\*\*\*Character %d = %s"%(guesschar, g))

` `current\_pw = current\_pw + g;

` `break

` `print

` `print("Password = %s"%current\_pw)

finally:

` `#Always close off things

` `ser.close()

` `ps.stop()

` `ps.close()\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Lista 9-3: Um script de exemplo para explorar o vazamento descoberto e adivinhar uma senha


Este script implementa o ataque básico de SPA: ele captura uma verificação de senha, usa a altura do pico em 148 + 25i para determinar se o caractere i está correto e simplesmente percorre todos os caracteres até encontrar a senha completa:

\*\*\*\*SENHA ENCONTRADA = ***ilovecheese***

Este script é um pouco lento para manter as coisas simples. Existem duas áreas para melhorar. Primeiro, o tempo limite na função ***serial.read***() está sempre definido para esperar por 500ms. Em vez disso, poderíamos procurar pela quebra de linha (\n) e parar de tentar ler mais dados. Segundo o firmware de verificação de senha no Arduino tem um atraso quando uma senha incorreta é inserida. Poderíamos usar uma linha de E/S para redefinir o chip do Arduino após cada tentativa para pular esse atraso. Deixaremos essas melhorias como um exercício para o leitor.

Ao analisar seus traços, você precisará examinar cuidadosamente os traços de energia. Dependendo de onde você posiciona o seu revelador, pode ser necessário inverter o sinal da comparação para que este exemplo funcione. Haverá vários locais mostrando o vazamento, então ajustes mínimos no código podem alterar seus resultados.

Se você quiser ver este exemplo rodando em hardware conhecido, o caderno complementar (veja <https://nostarch.com/hardwarehacking/>) mostra como usar um ***ChipWhisperer-Nano*** ou ***ChipWhisperer-Lite*** para se comunicar com o alvo Arduino. Além disso, o caderno complementar inclui traços de energia "pré-gravados" para que você possa executar este exemplo sem hardware.

No entanto, podemos tornar este ataque mais consistente mirando um dos alvos embutidos em vez do Arduino que você construiu, o que veremos a seguir. Além disso, trabalharemos para fazer um ataque mais automatizado que não exija que determinemos manualmente a localização e o valor do revelador.

**ChipWhisperer-Nano Exemplo:**

**Neste exemplo, vamos examinar um ataque semelhante no ChipWhisperer-Nano, que inclui o alvo, programador, osciloscópio e porta serial em um único pacote, o que significa que podemos nos concentrar no código de amostra e automatizar o ataque. Como em outros capítulos, você usará um caderno complementar (<https://nostarch.com/hardwarehacking/>); abra-o se tiver um ChipWhisperer-Nano.

Construção e Carregamento do Firmware** 

Primeiro, você precisa construir o software de exemplo (semelhante à Listagem 9-1) para o alvo do microcontrolador STM32F0. Você não precisa escrever seu próprio código, pois usará o código-fonte que faz parte do projeto ***ChipWhisperer***. A construção do firmware requer apenas a execução do comando ***make*** no notebook com a plataforma apropriada especificada, conforme mostrado na Lista 9-4.


\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**%%bash**

**cd ../hardware/victims/firmware/basic-passwdcheck**                                                                                     

**make PLATFORM=CWNANO CRYPTO\_TARGET=NONE
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_**
Lista 9-4: Construindo o ***firmware basic-passwdcheck,*** similar à Lista 9-1

Então você pode conectar-se ao alvo e programar o STM32F0 embarcado com o código do notebook da Lista 9-5.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

SCOPETYPE = 'OPENADC'

PLATFORM = 'CWNANO'

%run "Helper\_Scripts/Setup\_Generic.ipynb"

fw\_path = '../hardware/victims/firmware/basic-passwdcheck/basic-passwdcheck-CWNANO.hex'

cw.program\_target(scope, prog, fw\_path)

Lista 9-5: Configuração inicial e programação do alvo incluído com nosso firmware personalizado

Este código cria algumas configurações padrão para realizar a análise de potência e em seguida programa o arquivo ***hex*** do firmware construído na Lista 9-4.

**Um Primeiro Olhar na Comunicação**

Em seguida, vamos ver quais mensagens de inicialização o dispositivo está imprimindo ao reiniciar. O ambiente do notebook possui uma função chamada ***reset\_target***() que alterna a linha ***nRST*** para realizar um reset do alvo, após o qual podemos registrar os dados seriais recebidos. Para fazer isso, vamos executar o código do Lista 9-6.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

ret = ""

target.flush()

reset\_target(scope)

time.sleep(0.001)

num\_char = target.in\_waiting()

while num\_char > 0:

` `ret += target.read(timeout=10)

` `time.sleep(0.01)

` `num\_char = target.in\_waiting()

print(ret)
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Lista 9-6: Resetando o dispositivo e lendo as mensagens de inicialização.

Este ***reset*** resulta nas mensagens de inicialização mostradas na Listagem 9-7.

\*\*\*\*\*Safe-o-matic 3000 Booting...

Aligning bits........[DONE]

Checking Cesium RNG..[DONE]

Masquerading flash...[DONE]

Decrypting database..[DONE]

WARNING: UNAUTHORIZED ACCESS WILL BE PUNISHED

Please enter password to continue:

Lista 9-7: As mensagens de inicialização do código de verificação de senha de demonstração.

Parece que há uma segurança de inicialização séria... mas talvez possamos usar SPA para atacar a comparação de senha. Vamos ver o que está realmente implementado.



**Capturando um Traço** 

Como o ***ChipWhisperer*** integra tudo em uma única plataforma, é muito mais fácil construir uma função que realize uma captura de potência na comparação de senha. O código no Lista 9-8 define uma função que captura o traço de potência com uma senha de teste fornecida. A maior parte desse código é, na verdade, apenas esperar que as mensagens de inicialização terminem, após o qual o alvo está aguardando a entrada de uma senha.
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

def cap\_pass\_trace(pass\_guess):

` `ret = ""

` `reset\_target(scope)

` `time.sleep(0.01)

` `num\_char = target.in\_waiting()

` `#Wait for boot messages to finish so we are ready to enter password

` `while num\_char > 0:

` `ret += target.read(num\_char, 10)

` `time.sleep(0.01)

` `num\_char = target.in\_waiting()

` `scope.arm()

` `target.write(pass\_guess)

` `ret = scope.capture()

` `if ret:

` `print('Timeout happened during acquisition')

` `trace = scope.get\_last\_trace()

` `return trace
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
Lista 9-8: Função para registrar o traço de potência do processamento de qualquer senha arbitrária pelo alvo.

Próximo, simplesmente usamos **scope.arm()** para informar ao ***ChipWhisperer*** para aguardar o evento de gatilho. Enviamos a senha para o alvo, momento em que o alvo realizará a verificação da senha. Nosso alvo cooperativo está informando ao ***ChipWhisperer*** o momento em que a comparação está começando através do gatilho (neste caso, um pino GPIO que vai alto, que é um pouco de trapaça que adicionamos ao firmware do alvo). Finalmente, registramos o traço de potência e o passamos de volta para quem chamou a função. Com essa função definida, poderíamos executar o Lista 9-9 para capturar o traço.
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

%matplotlib notebook

import matplotlib.pylab as plt

trace = cap\_pass\_trace("hunter2\n")

plt.plot(trace[0:800], 'g')

Lista 9-9: Capturando o traço para uma senha específica

Aquele código deve gerar o traço de potência mostrado na Figura 9-11.

![Gráfico, Histograma

Descrição gerada automaticamente](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.011.png)

Figura 9-11: O consumo de energia do dispositivo enquanto processa uma senha específica.

Agora que temos a capacidade de capturar um traço de energia para uma senha específica, vamos ver se podemos transformá-la em um ataque.

**Do Traço para o Ataque**

Como antes, o primeiro passo é simplesmente enviar várias senhas diferentes e ver se notamos alguma diferença entre elas. O código no Exemplo 9-10 envia cinco senhas diferentes de um único caractere: 0, a, b, c ou h. Em seguida, ele gera um gráfico dos traços de energia durante o processamento dessas senhas. (Neste caso, nós trapaceamos, pois sabemos que a senha correta começa com h, mas queremos tornar as figuras resultantes razoavelmente visíveis. Na realidade, você pode ter que analisar várias figuras para encontrar o valor atípico - por exemplo, agrupando os caracteres iniciais a-h, i-p, q-x e y-z em gráficos separados.)

%matplotlib notebook

import matplotlib.pylab as plt

plt.figure(figsize=(10,4))

for guess in "0abch":

` `trace = cap\_pass\_trace(guess + "\n")

` `plt.plot(trace[0:100])

plt.show()

Lista 9-10: Um simples teste com os primeiros cinco caracteres das senhas





Os traços resultantes na Figura 9-12, que mostra as primeiras 100 amostras do consumo de energia conforme o dispositivo processa dois dos cinco diferentes primeiros caracteres de senhas. Um dos caracteres é o início correto da senha. Por volta da amostra 18, o consumo de energia dos caracteres diferentes começa a se desviar. Isso ocorre devido ao vazamento de tempo: se o loop sair cedo (porque o primeiro caractere está errado), a execução do código resultante seguirá um caminho diferente do caso em que o primeiro caractere está correto.

![Gráfico, Gráfico de linhas, Histograma

Descrição gerada automaticamente](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.012.png)

Figura 9-12: Consumo de energia para cinco caracteres iniciais diferentes

Se déssemos um zoom na Figura 9-12 e plotássemos todos os cinco traços de energia, veríamos que quatro caracteres têm praticamente o mesmo traço de energia, e um é claramente um desvio. Adivinharíamos que o desvio é o primeiro caractere correto, já que apenas um caractere pode estar correto. Em seguida, construímos um palpite usando o primeiro caractere correto e fazemos a mesma análise para o segundo caractere desconhecido.

**Usando a Soma de Diferenças Absolutas (SAD) para Encontrar a Senha (e Ficar Feliz)**

` `Em vez de ajustar minuciosamente o tempo de picos específicos como fizemos no início deste capítulo, poderíamos tentar ser um pouco mais espertos e talvez mais genéricos. Primeiro, poderíamos assumir que conhecemos uma senha que sempre falhará na comparação do primeiro caractere. Faremos um "traço de energia do modelo de senha inválida" e compararemos cada traço seguinte ao modelo. Neste caso, usaremos um único caractere definido como 0x00 em hexadecimal como uma senha inválida. Se observarmos uma diferença significativa entre o modelo e o traço de energia do dispositivo ao processar um caractere específico, isso sugere que aquele caractere específico está correto.

Um método simples de comparar duas matrizes é a Soma de Diferenças Absolutas (SAD). Para calcular a SAD, encontramos a diferença entre cada ponto em dois traços, transformamos isso em um número absoluto e depois somamos esses pontos. A SAD é uma medida de quão semelhantes dois traços são, onde 0 significa que eles são exatamente iguais, e números mais altos significam que os traços são menos semelhantes (consulte a Figura 9-13).

Se não somarmos os pontos e olharmos apenas para a diferença absoluta, podemos ver alguns padrões interessantes. Na Figura 9-13, pegamos o traço da senha inválida e calculamos a diferença absoluta com dois traços. Um traço foi obtido usando uma senha com o primeiro caractere errado (como e), mostrado como a linha inferior com um pico bem acima de 0.1. O outro traço foi obtido com uma senha com o primeiro caractere correto (h), mostrado como a linha superior barulhenta que paira logo acima de 0. A diferença em cada ponto é muito maior para a senha correta. Agora podemos somar todos esses pontos, calculando efetivamente a SAD. Devemos obter um valor grande para o caractere incorreto e um valor muito menor para o caractere correto.

![Gráfico

Descrição gerada automaticamente](Aspose.Words.2627b79c-45aa-49bb-b2cc-72b86092d6f5.013.png)

Figura 9-13: Diferenças absolutas nos traços para um caractere de senha correto (topo) e incorreto (parte inferior)

**Um Ataque de Um Único Caractere** 
Como agora temos uma métrica de "qualidade" na forma de SAD, podemos automatizar o ataque para o primeiro caractere. O código no Exemplo 9-11 mostra um script que passa por uma lista de palpites (neste caso, letras minúsculas e números) e verifica se algum deles resulta em um caminho de código claramente diferente. Se sim, ele marca isso como um caractere de senha provavelmente correto.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_bad\_trace = cap\_pass\_trace("\x00" + "\n")

for guess in "abcdefghijklmnopqrstuvwxyz0123456789":

` `diff = cap\_pass\_trace(guess + "\n") - bad\_trace

` `1 #print(sum(abs(diff)))

` `2 if sum(abs(diff)) > 80:

` `print("Best guess: " + guess)

` `break\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Lista 9-11: Testando um único caractere contra uma senha conhecida como inválida.

Você precisará ajustar o limiar para a sua configuração em 2, o que é feito mais facilmente removendo o comentário da declaração de impressão na linha 1 e verificando como as diferenças se parecem para senhas boas e ruins.

**Recuperação Completa de Senha**

Incorporar isso em um ataque completo requer apenas um pouco mais de esforço, como implementado no Exemplo 9-12. Como mencionado anteriormente, nosso modelo é construído usando uma senha inválida de um único caractere. Agora que usamos esse modelo para adivinhar o primeiro caractere, precisamos de outro modelo que represente "primeiro caractere correto, segundo caractere errado". Fazemos isso capturando um novo modelo a partir do consumo de energia do primeiro caractere de senha adivinhado, mais outro 0x00.
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

full\_guess = ""

while(len(full\_guess) < 5):

` `bad\_trace = cap\_pass\_trace(full\_guess + "\x00" + "\n")

` `1 if sum(abs(cap\_pass\_trace(full\_guess + "\x00" + "\n") - bad\_trace)) > 50:

` `continue

` `for guess in "abcdefghijklmnopqrstuvwxyz0123456789":

` `diff = cap\_pass\_trace(full\_guess + guess + "\n") - bad\_trace

` `if sum(abs(diff)) > 80:

` `full\_guess += guess

` `print("Best guess: " + full\_guess)

` `break
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Lista 9-12: Um script de ataque completo que descobre automaticamente a senha

Nós incluímos um mecanismo para validar que o novo modelo é representativo. As capturas às vezes podem ser ruidosas, e um traço de referência ruidoso gerará falsos positivos. Assim, um novo modelo é criado pegando dois traços de potência com a mesma senha (inválida) e garantindo que o SAD esteja abaixo de um limite em 1. Você precisará ajustar esse limite para sua configuração também. Uma solução mais robusta seria fazer a média de vários traços ou detectar automaticamente um traço que seja um outlier do conjunto completo. No entanto, os dois números mágicos 50 e 80 no Exemplo 9-12 são a forma mais simples de alcançar o objetivo. Ao executar este código, deve imprimir a senha completa h0px3. Isso é um ataque de sincronização SPA em apenas algumas linhas de Python.

**Resumo** 
Este capítulo concentrou-se em como realizar um simples ataque de sincronização usando análise de potência. Você pode usar os métodos descritos aqui para todos os tipos de ataques em sistemas reais. A única maneira de ter uma boa compreensão deles é por meio de experimentação prática. Quando chegar a hora de atacar sistemas reais, você também aprenderá que o primeiro passo é quase sempre caracterizar o sistema. Essas caracterizações seguem a mesma forma dos experimentos que você fez aqui, como simplesmente medir que tipo de vazamento você pode encontrar. Se você quiser tentar criptografia de chave pública para os exemplos de ataque SPA, você pode usar uma biblioteca de código aberto ***como avr-crypto-lib***. Você encontrará até mesmo portas desta biblioteca para Arduino. A plataforma ***ChipWhisperer*** ajuda a abstrair alguns dos detalhes sujos de hardware de baixo nível, para que você possa se concentrar nos aspectos mais interessantes e de alto nível do ataque. O site do ***ChipWhisperer*** inclui tutoriais e código de exemplo baseado em Python para se comunicar com uma variedade de dispositivos, incluindo vários osciloscópios, drivers de porta serial e leitores de smart card. Nem todos os alvos fazem parte da plataforma ***ChipWhisperer***, portanto, por esse motivo, pode ser benéfico implementar ataques "***bare-metal***" por conta própria. Em seguida, expandiremos este ataque simples para ler dados de um dispositivo em teste. Fazer isso significa não apenas ver que tipo de fluxo de programa está ocorrendo, mas também determinar realmente os dados secretos que estão sendo usados.






